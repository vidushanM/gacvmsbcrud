package pay;
import java.sql.Connection;

import java.sql.PreparedStatement;


public class PaymentController {
	public static int register(Payment pay){  
		int status=0; 
		Connection con = null;

		try{  
			con = DBcon.createConnection();

		PreparedStatement ps = con.prepareStatement("insert into payment values(?,?,?)");  
		ps.setString(1,pay.getId());  
		ps.setString(2,pay.getAmount());  
		ps.setString(3,pay.getDate());  
		              
		status=ps.executeUpdate();  
		
		}catch(Exception e){}  
		      
		return status;  
		}  
}
