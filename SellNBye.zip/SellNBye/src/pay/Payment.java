package pay;

public class Payment {
	
	private String Id,Amount,Date;  
	  
	public String getId() {  
	    return Id;  
	}  
	  
	public void setId(String Id) {  
	    this.Id = Id;  
	}  
	  
	public String getAmount() {  
	    return Amount;  
	}  
	  
	public void setAmount(String Amount) {  
	    this.Amount = Amount;  
	}  
	  
	public String getDate() {  
	    return Date;  
	}  
	  
	public void setDatel(String Date) {  
	    this.Date = Date;  
	}  
}
